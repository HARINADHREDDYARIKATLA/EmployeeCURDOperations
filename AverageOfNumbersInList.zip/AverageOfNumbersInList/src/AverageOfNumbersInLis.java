import java.util.ArrayList;
import java.util.List;

public class AverageOfNumbersInLis {

	public static void main(String[] args) {
		List<Integer> list =new ArrayList<>(); 
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		list.add(60);
		
		System.out.println("List of Numbers are "+list);
		double sum=0;
		for(Integer i:list) {
			sum+=i;
		}
		
		System.out.println("Average og numbers is = "+sum/list.size());

	}

}
